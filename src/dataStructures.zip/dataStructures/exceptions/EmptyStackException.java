package dataStructures.exceptions;

public class EmptyStackException extends RuntimeException {
    public EmptyStackException() {
        super();
    }
}
